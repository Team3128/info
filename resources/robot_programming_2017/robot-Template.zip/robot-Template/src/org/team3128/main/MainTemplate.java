package org.team3128.main;

import org.team3128.common.NarwhalRobot;
import org.team3128.common.util.GenericSendableChooser;

import edu.wpi.first.wpilibj.command.CommandGroup;

public class MainTemplate extends NarwhalRobot 
{
	
	@Override
	protected void constructHardware() 
	{
		
	}

	@Override
	protected void setupListeners() {
		
	}

	@Override
	protected void teleopInit() {

	}
	
	@Override
	protected void autonomousInit() {

	}
	
	protected void constructAutoPrograms(GenericSendableChooser<CommandGroup> programChooser)
	{		

	}
	
	@Override
	protected void updateDashboard() {
		
	}


	@Override
	protected void teleopPeriodic()
	{
		
	}
	
}
